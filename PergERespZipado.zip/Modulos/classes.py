class jogador:
    def __init__(self, nome, senha, saldo = 0):
        self.nome = nome
        self.senha = senha
        self.saldo = saldo
